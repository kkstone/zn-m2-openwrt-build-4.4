return {
	name = "doh.libredns.gr",
	label = _("LibreDNS - GR"),
	resolver_url = "https://doh.libredns.gr/dns-query",
	bootstrap_dns = "116.202.176.26,1.1.1.1",
	help_link = "https://libredns.gr/",
	help_link_text = "LibreDNS.gr"
}
