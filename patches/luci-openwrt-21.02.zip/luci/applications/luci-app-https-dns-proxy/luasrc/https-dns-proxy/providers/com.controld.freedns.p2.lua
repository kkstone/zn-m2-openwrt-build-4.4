return {
	name = "freedns.controld.com-p2",
	label = _("ControlD (Block Malware + Ads)"),
	resolver_url = "https://freedns.controld.com/p2",
	bootstrap_dns = "76.76.2.2,2606:1a40::2",
	help_link = "https://kb.controld.com/tutorials",
	help_link_text = "ControlD.com"
}
