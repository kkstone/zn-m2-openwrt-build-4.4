return {
	name = "dnsforge.de",
	label = _("DNS Forge - DE"),
	resolver_url = "https://dnsforge.de/dns-query",
	bootstrap_dns = "176.9.93.198,176.9.1.117,2a01:4f8:151:34aa::198,2a01:4f8:141:316d::117",
	help_link = "https://dnsforge.de/",
	help_link_text = "DNSForge.de"
}
