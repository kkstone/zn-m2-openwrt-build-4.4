return{
	name = "doh.pub",
	label = _("DNSPod Public DNS - CN"),
	resolver_url = "https://doh.pub/dns-query",
	bootstrap_dns = "119.29.29.29,119.28.28.28",
	help_link = "https://www.dnspod.com/Products/Public.DNS",
	help_link_text = "DNSPod.com"
}
