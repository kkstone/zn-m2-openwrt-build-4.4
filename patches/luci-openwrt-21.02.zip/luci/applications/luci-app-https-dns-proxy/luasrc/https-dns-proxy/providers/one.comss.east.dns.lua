return {
	name = "dns.east.comss.one",
	label = _("Comss.ru DNS (East)"),
	resolver_url = "https://dns.east.comss.one/dns-query",
	bootstrap_dns = "92.223.109.31,91.230.211.67,2a03:90c0:b5::1a,2a04:2fc0:39::47"
}
