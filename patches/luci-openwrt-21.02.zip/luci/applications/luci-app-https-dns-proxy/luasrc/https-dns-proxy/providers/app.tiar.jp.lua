return {
	name = "doh.tiar.jp",
	label = _("Tiarap Public DNS - JP"),
	resolver_url = "https://doh.tiar.jp/dns-query",
	bootstrap_dns = "172.104.93.80,2400:8902::f03c:91ff:feda:c514",
	help_link = "https://tiarap.org/",
	help_link_text = "Tiarap.org"
}
