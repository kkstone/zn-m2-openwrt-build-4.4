return {
	name = "doh.cleanbrowsing.org-doh-adult-filter",
	label = _("CleanBrowsing (Adult Filter)"),
	resolver_url = "https://doh.cleanbrowsing.org/doh/adult-filter/",
	bootstrap_dns = "185.228.168.168,1.1.1.1",
	help_link = "https://cleanbrowsing.org/guides/dnsoverhttps",
	help_link_text = "CleanBrowsing.org"
}
