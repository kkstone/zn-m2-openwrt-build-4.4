return {
	name = "dns.oszx.co",
	label = _("OSZX DNS - UK"),
	resolver_url = "https://dns.oszx.co/dns-query",
	bootstrap_dns = "51.38.83.141,2001:41d0:801:2000::d64",
	help_link = "https://dns.oszx.co/#mdoh",
	help_link_text = "OSZX.co"
}
