return {
	name = "doh.tiar.app",
	label = _("Tiarap Public DNS - SG"),
	resolver_url = "https://doh.tiar.app/dns-query",
	bootstrap_dns = "174.138.21.128,2400:6180:0:d0::5f6e:4001",
	help_link = "https://tiarap.org/",
	help_link_text = "Tiarap.org"
}
