return {
	name = "dnsforfamily",
	label = _("DNS For Family"),
	resolver_url = "https://dns-doh.dnsforfamily.com/dns-query",
	bootstrap_dns = "94.130.180.225,78.47.64.161",
	help_link = "https://dnsforfamily.com/#DNS_Servers_DNS_Over_HTTPS",
	help_link_text = "DNSForFamily.com"
}
