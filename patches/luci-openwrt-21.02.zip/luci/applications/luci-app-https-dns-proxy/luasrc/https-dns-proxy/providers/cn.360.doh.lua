return {
	name = "doh.360.cn",
	label = _("360 Secure DNS - CN"),
	resolver_url = "https://doh.360.cn/dns-query",
	bootstrap_dns = "101.226.4.6,218.30.118.6,123.125.81.6,140.207.198.6"
}
