-- Copyright 2014 Álvaro Fernández Rojas <noltari@gmail.com>
-- Licensed to the public under the Apache License 2.0.

module("luci.controller.shairport-sync", package.seeall)

function index()
	if not nixio.fs.access("/etc/config/shairport-sync") then
		return
	end

	local page = entry({"admin", "services", "shairport-sync"}, cbi("shairport-sync"), _("AirPlay 2 Receiver"))
	page.dependent = true
	page.acl_depends = { "luci-app-airplay2" }

	entry({"admin", "services", "shairport-sync", "status"}, call("act_status")).leaf = true
end

function act_status()
	local e = {}
	e.running = luci.sys.call("pgrep shairport-sync >/dev/null") == 0
	luci.http.prepare_content("application/json")
	luci.http.write_json(e)
end
